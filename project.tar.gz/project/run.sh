 pip3 freeze > requirements.txt
 pip3 install -r requirements.txt

 python3 video_feed.py & python3 main.py